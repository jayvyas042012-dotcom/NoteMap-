import { chromium } from "playwright";
import { readFileSync, writeFileSync } from "node:fs";

const serif = readFileSync("/workspace/.grok/fonts/InstrumentSerif-Regular.ttf").toString("base64");
const sans = readFileSync("/workspace/.grok/fonts/InstrumentSans-Regular.ttf").toString("base64");
const sansMed = readFileSync("/workspace/.grok/fonts/InstrumentSans-Medium.ttf").toString("base64");

const faces = `
@font-face { font-family: "Instrument Serif"; src: url(data:font/ttf;base64,${serif}) format("truetype"); font-weight: 400; font-style: normal; }
@font-face { font-family: "Instrument Sans"; src: url(data:font/ttf;base64,${sans}) format("truetype"); font-weight: 400; font-style: normal; }
@font-face { font-family: "Instrument Sans"; src: url(data:font/ttf;base64,${sansMed}) format("truetype"); font-weight: 500; font-style: normal; }
`;

const cardMap = `
<svg id="map" width="560" height="156" viewBox="0 0 560 156" fill="none" aria-hidden="true">
  <g stroke="#E7E4DC" stroke-width="1.6" stroke-linecap="round">
    <line x1="88" y1="72" x2="280" y2="70"/>
    <line x1="198" y1="24" x2="280" y2="70"/>
    <line x1="362" y1="28" x2="280" y2="70"/>
    <line x1="468" y1="66" x2="280" y2="70"/>
    <line x1="88" y1="72" x2="168" y2="130"/>
    <line x1="168" y1="130" x2="280" y2="70"/>
    <line x1="392" y1="126" x2="280" y2="70"/>
    <line x1="392" y1="126" x2="468" y2="66"/>
  </g>
  <circle cx="198" cy="24" r="8" fill="#F3F2EF"/>
  <circle cx="362" cy="28" r="7" fill="#F3F2EF"/>
  <circle cx="88" cy="72" r="10" fill="#F3F2EF"/>
  <circle cx="468" cy="66" r="11" fill="#F3F2EF"/>
  <circle cx="168" cy="130" r="8" fill="#F3F2EF"/>
  <circle cx="392" cy="126" r="9" fill="#F3F2EF"/>
  <circle cx="280" cy="70" r="18" fill="none" stroke="#E7E4DC" stroke-width="1.6"/>
  <circle cx="280" cy="70" r="11" fill="#F3F2EF"/>
</svg>`;

const bannerMap = `
<svg id="map" width="640" height="150" viewBox="0 0 640 150" fill="none" aria-hidden="true">
  <g stroke="#E7E4DC" stroke-width="1.6" stroke-linecap="round">
    <line x1="36" y1="76" x2="128" y2="38"/>
    <line x1="36" y1="76" x2="206" y2="94"/>
    <line x1="128" y1="38" x2="304" y2="42"/>
    <line x1="206" y1="94" x2="408" y2="76"/>
    <line x1="304" y1="42" x2="408" y2="76"/>
    <line x1="408" y1="76" x2="518" y2="36"/>
    <line x1="408" y1="76" x2="572" y2="108"/>
    <line x1="518" y1="36" x2="572" y2="108"/>
    <line x1="206" y1="94" x2="300" y2="122"/>
    <line x1="300" y1="122" x2="408" y2="76"/>
  </g>
  <circle cx="36" cy="76" r="8" fill="#F3F2EF"/>
  <circle cx="128" cy="38" r="10" fill="#F3F2EF"/>
  <circle cx="206" cy="94" r="11" fill="#F3F2EF"/>
  <circle cx="304" cy="42" r="8" fill="#F3F2EF"/>
  <circle cx="518" cy="36" r="9" fill="#F3F2EF"/>
  <circle cx="572" cy="108" r="8" fill="#F3F2EF"/>
  <circle cx="300" cy="122" r="7" fill="#F3F2EF"/>
  <circle cx="408" cy="76" r="18" fill="none" stroke="#E7E4DC" stroke-width="1.6"/>
  <circle cx="408" cy="76" r="11" fill="#F3F2EF"/>
</svg>`;

const base = `
  * { margin: 0; padding: 0; box-sizing: border-box; }
  html, body { overflow: hidden; }
  body {
    color: #F3F2EF;
    -webkit-font-smoothing: antialiased;
    text-rendering: geometricPrecision;
  }
  h1 {
    font-family: "Instrument Serif", Georgia, serif;
    font-weight: 400;
    font-style: normal;
    color: #F3F2EF;
  }
  .tag {
    font-family: "Instrument Sans", sans-serif;
    font-weight: 500;
    color: #E7E4DC;
  }
`;

const ogHtml = `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<style>
${faces}
${base}
html, body { width: 1200px; height: 630px; }
body {
  background:
    radial-gradient(ellipse 72% 62% at 50% 46%, #16181c 0%, #141618 42%, #0C0D0F 74%);
  display: flex;
  align-items: center;
  justify-content: center;
}
.lockup { display: flex; flex-direction: column; align-items: center; }
h1 { font-size: 214px; line-height: 0.92; letter-spacing: -0.03em; }
.tag { margin-top: 16px; font-size: 22px; line-height: 1; letter-spacing: 0.06em; }
#map { margin-top: 34px; }
</style>
</head>
<body>
  <div class="lockup">
    <h1 id="title">NoteMap</h1>
    <p id="tag" class="tag">Notes from any lesson</p>
    ${cardMap}
  </div>
</body>
</html>`;

const bannerHtml = `<!doctype html>
<html>
<head>
<meta charset="utf-8"/>
<style>
${faces}
${base}
html, body { width: 1200px; height: 264px; }
body {
  position: relative;
  background:
    radial-gradient(ellipse 48% 180% at 24% 36%, #16181c 0%, #141618 36%, #0C0D0F 70%);
}
.copy { position: absolute; left: 68px; top: 30px; }
h1 { font-size: 64px; line-height: 0.9; letter-spacing: -0.035em; }
.tag { margin-top: 12px; font-size: 15px; line-height: 1; letter-spacing: 0.08em; }
#map { position: absolute; left: 500px; top: 42px; }
</style>
</head>
<body>
  <div class="copy">
    <h1 id="title">NoteMap</h1>
    <p id="tag" class="tag">Notes from any lesson</p>
  </div>
  ${bannerMap}
</body>
</html>`;

writeFileSync("/workspace/.grok/og-card.html", ogHtml);
writeFileSync("/workspace/.grok/x-banner.html", bannerHtml);

function assertBox(name, box, rules) {
  if (!box) throw new Error(`${name} has no box`);
  const right = box.x + box.width;
  const bottom = box.y + box.height;
  const info = `${name} x=${box.x.toFixed(1)} y=${box.y.toFixed(1)} r=${right.toFixed(1)} b=${bottom.toFixed(1)} w=${box.width.toFixed(1)}`;
  console.log(info);
  for (const [label, ok] of rules) {
    if (!ok(box, right, bottom)) throw new Error(`${name} failed ${label}: ${info}`);
  }
}

const browser = await chromium.launch({
  headless: true,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
});

async function shoot(html, width, height, path, check) {
  const context = await browser.newContext({
    viewport: { width, height },
    deviceScaleFactor: 2,
  });
  const page = await context.newPage();
  await page.setContent(html, { waitUntil: "load" });
  await page.evaluate(async () => { await document.fonts.ready; });
  const family = await page.evaluate(() => getComputedStyle(document.querySelector("#title")).fontFamily);
  console.log(path, "font", family);
  if (!family.includes("Instrument Serif")) throw new Error(`serif did not load for ${path}: ${family}`);
  const title = await page.locator("#title").boundingBox();
  const tag = await page.locator("#tag").boundingBox();
  check(title, tag);
  await page.screenshot({ path, type: "png" });
  await context.close();
}

await shoot(ogHtml, 1200, 630, "/workspace/.grok/og-raw.png", (title, tag) => {
  const inside = (box, right, bottom) => box.x >= 48 && box.y >= 40 && right <= 1152 && bottom <= 590;
  assertBox("og-title", title, [
    ["margins", inside],
    ["width", (box) => box.width >= 500 && box.width <= 800],
  ]);
  assertBox("og-tag", tag, [
    ["margins", inside],
    ["under title", (box) => box.y >= title.y + title.height - 4],
    ["narrower than title", (box) => box.width < title.width],
  ]);
});

await shoot(bannerHtml, 1200, 264, "/workspace/.grok/x-banner-raw.png", (title, tag) => {
  const safe = (box, right, bottom) => box.x >= 48 && right <= 560 && box.y >= 16 && bottom <= 132;
  assertBox("banner-title", title, [["safe lockup", safe]]);
  assertBox("banner-tag", tag, [
    ["safe lockup", safe],
    ["under title", (box) => box.y >= title.y + title.height - 2],
  ]);
});

await browser.close();
console.log("rendered");
