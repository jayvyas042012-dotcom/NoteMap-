import { useEffect, useRef, useState } from "react";
import {
  BookOpen,
  ChevronRight,
  FileText,
  Image as ImageIcon,
  Library,
  ListChecks,
  LoaderCircle,
  Music,
  Pause,
  Play,
  Plus,
  Trash2,
  Waypoints,
  X,
} from "lucide-react";
import { generateStudyPack, singStudySong } from "@/lib/study/api";
import { errorText, kindLabel, langLabel, packLangName, questionProgress, sourceCountLabel, t } from "@/lib/study/i18n";
import { samplePack } from "@/lib/study/sample";
import { useStudy } from "@/lib/study/store";
import type { DraftSource, Lang, MindNode, QuizQuestion, StudyPack } from "@/lib/study/types";
import { SAMPLE_ID } from "@/lib/study/types";

const LANGS: Lang[] = ["en", "hi", "hinglish"];
const audioMemory = new Map<string, string>();

function nid(): string {
  return `s${Math.random().toString(36).slice(2, 9)}`;
}

function videoThumb(url?: string): string | null {
  const id = url?.match(/v=([A-Za-z0-9_-]{11})/)?.[1];
  return id ? `https://i.ytimg.com/vi/${id}/mqdefault.jpg` : null;
}

function hashText(value: string): string {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) hash = (Math.imul(31, hash) + value.charCodeAt(i)) | 0;
  return String(hash);
}

function readAudio(key: string): string | null {
  if (audioMemory.has(key)) return audioMemory.get(key) ?? null;
  try {
    const raw = localStorage.getItem("notemap-audio-v1");
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Record<string, string>;
    const hit = parsed[key];
    if (hit) audioMemory.set(key, hit);
    return hit ?? null;
  } catch {
    return null;
  }
}

function writeAudio(key: string, value: string) {
  audioMemory.set(key, value);
  try {
    const raw = localStorage.getItem("notemap-audio-v1");
    const parsed = raw ? (JSON.parse(raw) as Record<string, string>) : {};
    const keys = Object.keys(parsed);
    if (keys.length > 3) delete parsed[keys[0]];
    parsed[key] = value;
    localStorage.setItem("notemap-audio-v1", JSON.stringify(parsed));
  } catch {
    /* the in-memory copy still plays */
  }
}

async function fileToBase64(file: File): Promise<string> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("bad_file"));
    reader.readAsDataURL(file);
  });
  const comma = dataUrl.indexOf(",");
  return comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
}

async function compressImage(file: File): Promise<{ mime: string; base64: string; preview: string }> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, 1280 / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(8, Math.round(bitmap.width * scale));
  const height = Math.max(8, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("bad_file");
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  let quality = 0.72;
  let preview = canvas.toDataURL("image/jpeg", quality);
  while (preview.length > 900_000 && quality > 0.4) {
    quality -= 0.12;
    preview = canvas.toDataURL("image/jpeg", quality);
  }
  if (preview.length > 1_300_000) throw new Error("too_big");
  return { mime: "image/jpeg", base64: preview.slice(preview.indexOf(",") + 1), preview };
}

function toPayload(language: Lang, drafts: DraftSource[]) {
  return {
    language,
    sources: drafts.map((draft) => {
      if (draft.kind === "youtube") {
        return {
          id: draft.id,
          kind: "youtube" as const,
          url: draft.url,
          transcript: draft.transcript.trim() || undefined,
        };
      }
      if (draft.kind === "image") {
        return { id: draft.id, kind: "image" as const, name: draft.name, mime: draft.mime, base64: draft.base64 };
      }
      return { id: draft.id, kind: "pdf" as const, name: draft.name, base64: draft.base64 };
    }),
  };
}

export function NoteMapApp() {
  const lang = useStudy((state) => state.lang);
  const name = useStudy((state) => state.name);
  const packs = useStudy((state) => state.packs);
  const activeId = useStudy((state) => state.activeId);
  const xp = useStudy((state) => state.xp);
  const lastDelta = useStudy((state) => state.lastDelta);
  const lastDeltaAt = useStudy((state) => state.lastDeltaAt);
  const setLang = useStudy((state) => state.setLang);
  const setName = useStudy((state) => state.setName);
  const setActive = useStudy((state) => state.setActive);
  const addPack = useStudy((state) => state.addPack);
  const replacePack = useStudy((state) => state.replacePack);
  const removePack = useStudy((state) => state.removePack);
  const clearDelta = useStudy((state) => state.clearDelta);
  const draftsRef = useRef(new Map<string, DraftSource[]>());
  const panelRef = useRef<HTMLElement>(null);
  const choiceRef = useRef<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);
  const [ready, setReady] = useState(false);
  const [draftName, setDraftName] = useState("");
  const [busy, setBusy] = useState(false);
  const [fixError, setFixError] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    const finish = () => {
      if (!alive) return;
      setReady(true);
      if (choiceRef.current) setActive(choiceRef.current);
    };
    const timer = window.setTimeout(finish, 500);
    void Promise.resolve(useStudy.persist.rehydrate()).finally(() => {
      window.clearTimeout(timer);
      finish();
    });
    return () => {
      alive = false;
      window.clearTimeout(timer);
    };
  }, [setActive]);

  function choose(id: string) {
    choiceRef.current = id;
    setActive(id);
  }

  useEffect(() => {
    if (activeId !== "new") return;
    const node = panelRef.current;
    if (!node) return;
    const top = node.getBoundingClientRect().top;
    if (top < 8 || top > window.innerHeight * 0.55) {
      node.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  }, [activeId]);

  useEffect(() => {
    document.documentElement.lang = lang === "hi" ? "hi" : "en";
  }, [lang]);

  useEffect(() => {
    if (lastDelta === null) return;
    const timer = window.setTimeout(() => clearDelta(), 1400);
    return () => window.clearTimeout(timer);
  }, [lastDelta, lastDeltaAt, clearDelta]);

  const active: StudyPack =
    activeId === SAMPLE_ID ? samplePack(lang) : (packs.find((pack) => pack.id === activeId) ?? samplePack(lang));
  const showingComposer = activeId === "new";

  async function runDrafts(drafts: DraftSource[], previousId?: string) {
    setBusy(true);
    setFixError(null);
    try {
      const result = await generateStudyPack({ data: toPayload(lang, drafts) });
      if (!result.ok) {
        setFixError(errorText(lang, result.error));
        return;
      }
      const pack: StudyPack = {
        ...result.pack,
        id: previousId ?? crypto.randomUUID(),
        createdAt: Date.now(),
        language: lang,
      };
      draftsRef.current.set(pack.id, drafts);
      if (previousId) replacePack(pack);
      else addPack(pack);
    } catch {
      setFixError(t(lang, "genError"));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="min-h-screen bg-ink text-paper">
      <header className="sticky top-0 z-20 border-b border-line bg-ink">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-w-0">
            <h1 className="font-serif text-3xl leading-none tracking-tight text-balance">NoteMap</h1>
            <p className="mt-1 max-w-xl text-sm text-pretty text-mist">{t(lang, "tagline")}</p>
            <p className="mt-1 text-sm text-faint">Made by Jay Vyas, a 15-year-old entrepreneur</p>
            {ready && name ? (
              <p className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm">
                <span className="font-medium text-paper">
                  {t(lang, "hiName")}, {name}
                </span>
                <button type="button" onClick={() => setName("")} className="text-mist underline-offset-2 hover:underline">
                  {t(lang, "notYou")}
                </button>
              </p>
            ) : null}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex rounded-lg bg-panel p-1" role="group" aria-label={t(lang, "madeIn")}>
              {LANGS.map((item) => (
                <button
                  key={item}
                  type="button"
                  aria-pressed={lang === item}
                  onClick={() => setLang(item)}
                  className={`min-h-11 rounded-md px-3 text-sm font-medium ${
                    lang === item ? "bg-accent text-accent-ink" : "text-mist hover:text-paper"
                  }`}
                >
                  {langLabel(lang, item)}
                </button>
              ))}
            </div>
            <XpPill lang={lang} xp={xp} delta={lastDelta} />
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-4 px-4 py-4 lg:grid-cols-4 lg:py-6">
        <div className="order-1 lg:col-start-1 lg:row-start-1">
          <button
            type="button"
            aria-pressed={showingComposer}
            onClick={() => choose("new")}
            className={`flex min-h-11 w-full items-center justify-center gap-2 rounded-lg px-3 text-sm font-medium ${
              showingComposer ? "bg-paper text-ink" : "bg-accent text-accent-ink"
            }`}
          >
            <Plus className="size-4" aria-hidden="true" />
            {t(lang, "newStudy")}
          </button>
        </div>

        <section ref={panelRef} className="order-2 min-w-0 scroll-mt-24 lg:col-span-3 lg:col-start-2 lg:row-span-2 lg:row-start-1">
          {ready && !name ? (
            <form
              className="mb-4 rounded-3xl border border-line bg-panel p-4"
              onSubmit={(event) => {
                event.preventDefault();
                const next = draftName.trim();
                if (next) setName(next);
              }}
            >
              <p className="text-sm font-medium">{t(lang, "whoTitle")}</p>
              <p className="mt-1 text-sm text-mist">{t(lang, "whoBody")}</p>
              <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                <input
                  value={draftName}
                  onChange={(event) => setDraftName(event.target.value)}
                  placeholder={t(lang, "whoPlaceholder")}
                  maxLength={40}
                  autoComplete="name"
                  className="h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm text-paper outline-none placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-paper"
                />
                <button
                  type="submit"
                  disabled={!draftName.trim()}
                  className="h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-ink disabled:opacity-50"
                >
                  {t(lang, "whoSave")}
                </button>
              </div>
            </form>
          ) : null}
          {showingComposer ? (
            <Composer lang={lang} busy={busy} error={fixError} onMake={(drafts) => runDrafts(drafts)} />
          ) : (
            <PackView
              pack={active}
              lang={lang}
              busy={busy}
              error={fixError}
              canFix={active.id !== SAMPLE_ID}
              onFix={async (sourceId, transcript) => {
                const existing = draftsRef.current.get(active.id);
                if (!existing) {
                  const youtube = active.sources.filter((item) => item.kind === "youtube" && item.url);
                  const onlyThis =
                    active.sources.length === 1 && youtube.length === 1 && youtube[0]?.id === sourceId && youtube[0].url;
                  if (!onlyThis || !youtube[0]?.url) {
                    setFixError(t(lang, "lostFiles"));
                    return;
                  }
                  await runDrafts([{ id: sourceId, kind: "youtube", url: youtube[0].url, transcript }], active.id);
                  return;
                }
                const next = existing.map((draft) =>
                  draft.kind === "youtube" && draft.id === sourceId ? { ...draft, transcript } : draft,
                );
                await runDrafts(next, active.id);
              }}
            />
          )}
        </section>

        <aside className="order-3 lg:col-start-1 lg:row-start-2">
          <div className="rounded-3xl border border-line bg-panel p-4">
            <p className="flex items-center gap-2 text-sm font-medium text-mist">
              <Library className="size-4" aria-hidden="true" />
              {t(lang, "library")}
            </p>
            <ul className="mt-2 flex flex-col gap-1">
              <LibraryRow
                title={samplePack(lang).title}
                meta={t(lang, "sample")}
                active={!showingComposer && (activeId === SAMPLE_ID || !packs.some((pack) => pack.id === activeId))}
                onOpen={() => choose(SAMPLE_ID)}
              />
              {ready && packs.length === 0 ? <li className="px-2 py-3 text-sm text-mist">{t(lang, "emptyLibrary")}</li> : null}
              {packs.map((pack) => (
                <LibraryRow
                  key={pack.id}
                  title={pack.title}
                  meta={sourceCountLabel(lang, pack.sources.length)}
                  active={!showingComposer && activeId === pack.id}
                  confirm={confirmId === pack.id}
                  onOpen={() => {
                    setConfirmId(null);
                    choose(pack.id);
                  }}
                  onRemove={() => {
                    if (confirmId === pack.id) {
                      removePack(pack.id);
                      draftsRef.current.delete(pack.id);
                      setConfirmId(null);
                    } else {
                      setConfirmId(pack.id);
                    }
                  }}
                  removeLabel={confirmId === pack.id ? t(lang, "confirmRemove") : t(lang, "remove")}
                />
              ))}
            </ul>
          </div>
        </aside>
      </main>
    </div>
  );
}

function XpPill({ lang, xp, delta }: { lang: Lang; xp: number; delta: number | null }) {
  const tone = delta === null || delta === 0 ? "text-paper" : delta > 0 ? "text-good" : "text-bad";
  return (
    <div className="flex min-h-11 items-center gap-2 rounded-lg bg-panel px-3">
      <span className="text-xs font-medium text-mist">{t(lang, "xp")}</span>
      <span className={`text-lg font-medium tabular-nums ${tone}`}>{xp}</span>
      {delta !== null && delta !== 0 ? (
        <span className={`animate-rise text-sm font-medium tabular-nums ${tone}`}>{delta > 0 ? `+${delta}` : delta}</span>
      ) : null}
    </div>
  );
}

function LibraryRow({
  title,
  meta,
  active,
  confirm,
  onOpen,
  onRemove,
  removeLabel,
}: {
  title: string;
  meta: string;
  active: boolean;
  confirm?: boolean;
  onOpen: () => void;
  onRemove?: () => void;
  removeLabel?: string;
}) {
  return (
    <li className={`rounded-lg ${active ? "bg-panel-2" : ""}`}>
      <div className="flex items-stretch">
        <button type="button" onClick={onOpen} className="min-h-11 min-w-0 flex-1 px-2 py-2 text-left">
          <span className="block truncate text-sm font-medium">{title}</span>
          <span className="block text-xs text-mist">{meta}</span>
        </button>
        {onRemove ? (
          <button
            type="button"
            onClick={onRemove}
            aria-label={removeLabel}
            className={`min-h-11 px-2 text-xs ${confirm ? "text-bad" : "text-faint hover:text-paper"}`}
          >
            {confirm ? removeLabel : <Trash2 className="mx-auto size-4" aria-hidden="true" />}
          </button>
        ) : null}
      </div>
    </li>
  );
}

function Composer({
  lang,
  busy,
  error,
  onMake,
}: {
  lang: Lang;
  busy: boolean;
  error: string | null;
  onMake: (drafts: DraftSource[]) => Promise<void>;
}) {
  const [drafts, setDrafts] = useState<DraftSource[]>([]);
  const [link, setLink] = useState("");
  const [openTranscript, setOpenTranscript] = useState<string | null>(null);
  const [localError, setLocalError] = useState<string | null>(null);
  const [over, setOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const message = localError || error;

  function addLink() {
    const url = link.trim();
    if (!url) return;
    const matched =
      url.match(/(?:v=|youtu\.be\/|shorts\/|embed\/|live\/)([A-Za-z0-9_-]{11})/) ??
      (/^[A-Za-z0-9_-]{11}$/.test(url) ? [url, url] : null);
    if (!matched) {
      setLocalError(t(lang, "notYoutube"));
      return;
    }
    if (drafts.length >= 5) {
      setLocalError(t(lang, "tooMany"));
      return;
    }
    const watch = `https://www.youtube.com/watch?v=${matched[1]}`;
    if (drafts.some((draft) => draft.kind === "youtube" && draft.url === watch)) {
      setLink("");
      return;
    }
    setDrafts((current) => [...current, { id: nid(), kind: "youtube", url: watch, transcript: "" }]);
    setLink("");
    setLocalError(null);
  }

  async function addFiles(files: FileList | File[]) {
    const list = [...files];
    let next = [...drafts];
    let problem: string | null = null;
    for (const file of list) {
      if (next.length >= 5) {
        problem = t(lang, "tooMany");
        break;
      }
      const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf");
      const isImage = file.type.startsWith("image/");
      if (!isPdf && !isImage) {
        problem = t(lang, "badFile");
        continue;
      }
      try {
        if (isPdf) {
          if (file.size > 4_000_000) throw new Error("too_big");
          const base64 = await fileToBase64(file);
          next = [...next, { id: nid(), kind: "pdf", name: file.name, base64 }];
        } else {
          const image = await compressImage(file);
          next = [...next, { id: nid(), kind: "image", name: file.name, ...image }];
        }
      } catch (caught) {
        problem = caught instanceof Error && caught.message === "too_big" ? t(lang, "tooBig") : t(lang, "badFile");
      }
    }
    setDrafts(next);
    setLocalError(problem);
  }

  return (
    <div className="rounded-3xl border border-line bg-panel p-4 sm:p-5">
      <p className="text-xs font-medium text-mist">{t(lang, "newStudy")}</p>
      <h2 className="mt-1 font-serif text-3xl tracking-tight text-balance">{t(lang, "composerTitle")}</h2>
      <p className="mt-2 max-w-2xl text-sm leading-relaxed text-pretty text-mist">{t(lang, "composerBody")}</p>

      <div className="mt-5 flex flex-col gap-2 sm:flex-row">
        <label className="min-w-0 flex-1">
          <span className="sr-only">{t(lang, "ytPlaceholder")}</span>
          <input
            value={link}
            onChange={(event) => setLink(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") {
                event.preventDefault();
                addLink();
              }
            }}
            placeholder={t(lang, "ytPlaceholder")}
            className="h-11 w-full rounded-lg border border-line bg-ink px-3 text-sm text-paper outline-none placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-paper"
          />
        </label>
        <button type="button" onClick={addLink} className="h-11 rounded-lg border border-line bg-panel-2 px-4 text-sm font-medium">
          {t(lang, "add")}
        </button>
      </div>

      <div
        onDragOver={(event) => {
          event.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(event) => {
          event.preventDefault();
          setOver(false);
          void addFiles(event.dataTransfer.files);
        }}
        className={`mt-3 rounded-lg border border-dashed px-4 py-6 text-center ${over ? "border-paper" : "border-line"}`}
      >
        <p className="text-sm text-mist">{t(lang, "drop")}</p>
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="mt-3 h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-ink"
        >
          {t(lang, "browse")}
        </button>
        <input
          ref={fileRef}
          type="file"
          accept="image/png,image/jpeg,image/webp,application/pdf"
          multiple
          className="sr-only"
          onChange={(event) => {
            if (event.target.files) void addFiles(event.target.files);
            event.target.value = "";
          }}
        />
      </div>

      {drafts.length > 0 ? (
        <div className="mt-4">
          <p className="text-sm text-mist">{t(lang, "covers")}</p>
          <ul className="mt-2 flex flex-col gap-2">
            {drafts.map((draft, index) => (
              <li key={draft.id} className="rounded-lg bg-panel-2 p-3">
                <div className="flex items-center gap-3">
                  <SourceIcon kind={draft.kind} />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-mist">
                      {index + 1}. {kindLabel(lang, draft.kind)}
                    </p>
                    <p className="truncate text-sm">
                      {draft.kind === "youtube" ? draft.url.replace("https://www.youtube.com/watch?v=", "") : draft.name}
                    </p>
                  </div>
                  {draft.kind === "image" ? <img src={draft.preview} alt="" className="h-11 w-11 rounded-md object-cover" /> : null}
                  <button
                    type="button"
                    aria-label={t(lang, "remove")}
                    onClick={() => setDrafts((current) => current.filter((item) => item.id !== draft.id))}
                    className="flex size-11 items-center justify-center text-faint hover:text-paper"
                  >
                    <X className="size-4" aria-hidden="true" />
                  </button>
                </div>
                {draft.kind === "youtube" ? (
                  <div className="mt-2">
                    <button
                      type="button"
                      onClick={() => setOpenTranscript((current) => (current === draft.id ? null : draft.id))}
                      className="text-sm text-mist underline-offset-2 hover:underline"
                    >
                      {openTranscript === draft.id ? t(lang, "hideTranscript") : t(lang, "addTranscript")}
                    </button>
                    {openTranscript === draft.id ? (
                      <textarea
                        value={draft.transcript}
                        onChange={(event) =>
                          setDrafts((current) =>
                            current.map((item) =>
                              item.id === draft.id && item.kind === "youtube" ? { ...item, transcript: event.target.value } : item,
                            ),
                          )
                        }
                        placeholder={t(lang, "transcriptPlaceholder")}
                        rows={4}
                        className="mt-2 w-full rounded-lg border border-line bg-ink px-3 py-2 text-sm outline-none placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-paper"
                      />
                    ) : null}
                  </div>
                ) : null}
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {message ? (
        <p role="alert" className="mt-4 text-sm text-bad">
          {message}
        </p>
      ) : null}

      <button
        type="button"
        disabled={busy || drafts.length === 0}
        onClick={() => {
          if (drafts.length === 0) {
            setLocalError(t(lang, "needSource"));
            return;
          }
          setLocalError(null);
          void onMake(drafts);
        }}
        className="mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-accent text-sm font-medium text-accent-ink disabled:opacity-50 sm:w-auto sm:px-5"
      >
        {busy ? <LoaderCircle className="size-4 animate-spin" aria-hidden="true" /> : <BookOpen className="size-4" aria-hidden="true" />}
        {busy ? t(lang, "making") : t(lang, "make")}
      </button>
      {busy ? <p className="mt-2 text-sm text-mist">{t(lang, "makingHint")}</p> : null}
    </div>
  );
}

function SourceIcon({ kind }: { kind: DraftSource["kind"] }) {
  const className = "size-4 text-mist";
  if (kind === "youtube") return <Play className={className} aria-hidden="true" />;
  if (kind === "image") return <ImageIcon className={className} aria-hidden="true" />;
  return <FileText className={className} aria-hidden="true" />;
}

function PackView({
  pack,
  lang,
  busy,
  error,
  canFix,
  onFix,
}: {
  pack: StudyPack;
  lang: Lang;
  busy: boolean;
  error: string | null;
  canFix: boolean;
  onFix: (sourceId: string, transcript: string) => Promise<void>;
}) {
  const [tab, setTab] = useState<"notes" | "map" | "quiz" | "song">("notes");
  const tabs = [
    { id: "notes" as const, label: t(lang, "notes"), icon: BookOpen },
    { id: "map" as const, label: t(lang, "map"), icon: Waypoints },
    { id: "quiz" as const, label: t(lang, "quiz"), icon: ListChecks },
    { id: "song" as const, label: t(lang, "song"), icon: Music },
  ];

  return (
    <div className="rounded-3xl border border-line bg-panel p-4 sm:p-5">
      <p className="text-xs text-mist">
        {pack.id === SAMPLE_ID ? t(lang, "sample") : packLangName(lang, pack.language)} · {sourceCountLabel(lang, pack.sources.length)}
      </p>
      <h2 className="mt-1 font-serif text-3xl tracking-tight text-balance">{pack.title}</h2>
      <div className="mt-4 flex gap-1 overflow-x-auto rounded-lg bg-ink p-1" role="tablist">
        {tabs.map((item) => {
          const Icon = item.icon;
          const selected = tab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              role="tab"
              aria-selected={selected}
              onClick={() => setTab(item.id)}
              className={`flex min-h-11 flex-1 items-center justify-center gap-2 rounded-md px-3 text-sm font-medium whitespace-nowrap ${
                selected ? "bg-panel-2 text-paper" : "text-mist"
              }`}
            >
              <Icon className="size-4" aria-hidden="true" />
              {item.label}
            </button>
          );
        })}
      </div>
      <div className="mt-4" role="tabpanel">
        {tab === "notes" ? <Notes pack={pack} lang={lang} busy={busy} error={error} canFix={canFix} onFix={onFix} /> : null}
        {tab === "map" ? <MindMap node={pack.mindmap} hint={t(lang, "mapHint")} /> : null}
        {tab === "quiz" ? <Quiz pack={pack} lang={lang} /> : null}
        {tab === "song" ? <SongPanel pack={pack} uiLang={lang} /> : null}
      </div>
    </div>
  );
}

function Notes({
  pack,
  lang,
  busy,
  error,
  canFix,
  onFix,
}: {
  pack: StudyPack;
  lang: Lang;
  busy: boolean;
  error: string | null;
  canFix: boolean;
  onFix: (sourceId: string, transcript: string) => Promise<void>;
}) {
  return (
    <div className="flex flex-col gap-5">
      {pack.notes.map((note) => {
        const source = pack.sources.find((item) => item.id === note.sourceId);
        const thumb = videoThumb(source?.url);
        return (
          <article key={note.sourceId} className="border-t border-line pt-4 first:border-t-0 first:pt-0">
            <div className="flex gap-3">
              {thumb ? <img src={thumb} alt="" className="h-16 w-28 shrink-0 rounded-lg object-cover" /> : null}
              <div className="min-w-0">
                <p className="text-xs font-medium text-mist">{source ? kindLabel(lang, source.kind) : t(lang, "notes")}</p>
                <h3 className="text-lg font-medium text-balance">{note.heading}</h3>
              </div>
            </div>
            {source?.warning ? <p className="mt-3 text-sm leading-relaxed text-mist">{source.warning}</p> : null}
            {source?.warning && source.kind === "youtube" && canFix ? (
              <TranscriptFix lang={lang} busy={busy} onFix={(transcript) => onFix(source.id, transcript)} />
            ) : null}
            <p className="mt-3 text-sm leading-relaxed text-pretty">{note.summary}</p>
            <ul className="mt-3 flex list-disc flex-col gap-1 pl-5 text-sm leading-relaxed">
              {note.bullets.map((bullet) => (
                <li key={bullet}>{bullet}</li>
              ))}
            </ul>
            {note.keyTerms.length > 0 ? (
              <div className="mt-4">
                <h4 className="text-sm font-medium">{t(lang, "keyTerms")}</h4>
                <dl className="mt-2 flex flex-col gap-2">
                  {note.keyTerms.map((term) => (
                    <div key={term.term}>
                      <dt className="text-sm font-medium">{term.term}</dt>
                      <dd className="text-sm text-mist">{term.meaning}</dd>
                    </div>
                  ))}
                </dl>
              </div>
            ) : null}
          </article>
        );
      })}
      {error ? (
        <p role="alert" className="text-sm text-bad">
          {error}
        </p>
      ) : null}
    </div>
  );
}

function TranscriptFix({ lang, busy, onFix }: { lang: Lang; busy: boolean; onFix: (transcript: string) => Promise<void> }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("");
  if (!open) {
    return (
      <button type="button" onClick={() => setOpen(true)} className="mt-2 text-sm text-paper underline-offset-2 hover:underline">
        {t(lang, "pasteHint")}
      </button>
    );
  }
  return (
    <div className="mt-3">
      <textarea
        value={value}
        onChange={(event) => setValue(event.target.value)}
        rows={5}
        placeholder={t(lang, "transcriptPlaceholder")}
        className="w-full rounded-lg border border-line bg-ink px-3 py-2 text-sm outline-none placeholder:text-faint focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-paper"
      />
      <button
        type="button"
        disabled={busy || value.trim().length < 40}
        onClick={() => void onFix(value.trim())}
        className="mt-2 h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-ink disabled:opacity-50"
      >
        {busy ? t(lang, "updating") : t(lang, "updateWithTranscript")}
      </button>
    </div>
  );
}

function MindMap({ node, hint }: { node: MindNode; hint: string }) {
  return (
    <div>
      <p className="text-sm text-mist">{hint}</p>
      <div className="mt-4 min-w-0 max-w-full overflow-x-auto rounded-lg bg-ink p-4">
        <div className="flex w-max items-center">
          <p className="max-w-56 rounded-2xl bg-accent px-4 py-3 font-serif text-2xl leading-tight text-balance text-accent-ink">
            {node.label}
          </p>
          {node.children.length > 0 ? <span className="h-px w-8 shrink-0 bg-line" aria-hidden="true" /> : null}
          <ul className="flex flex-col justify-center gap-3 border-l border-line">
            {node.children.map((child) => (
              <li key={child.id} className="flex items-center">
                <span className="h-px w-6 shrink-0 bg-line" aria-hidden="true" />
                <Branch node={child} />
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

function Branch({ node }: { node: MindNode }) {
  const [open, setOpen] = useState(true);
  const hasChildren = node.children.length > 0;
  return (
    <div className="flex items-center">
      <button
        type="button"
        onClick={() => hasChildren && setOpen((value) => !value)}
        aria-expanded={hasChildren ? open : undefined}
        className="flex min-h-11 max-w-64 items-center gap-2 rounded-lg border border-line bg-panel px-3 py-2 text-left"
      >
        {hasChildren ? (
          <ChevronRight
            className={`size-4 shrink-0 transition-transform duration-150 ${open ? "rotate-90" : ""}`}
            aria-hidden="true"
          />
        ) : (
          <span className="size-1.5 shrink-0 rounded-full bg-mist" aria-hidden="true" />
        )}
        <span className="text-sm leading-snug text-pretty">{node.label}</span>
      </button>
      {hasChildren && open ? (
        <>
          <span className="h-px w-5 shrink-0 bg-line" aria-hidden="true" />
          <ul className="flex flex-col gap-2 border-l border-line">
            {node.children.map((child) => (
              <li key={child.id} className="flex items-center">
                <span className="h-px w-5 shrink-0 bg-line" aria-hidden="true" />
                <Branch node={child} />
              </li>
            ))}
          </ul>
        </>
      ) : null}
    </div>
  );
}

function Quiz({ pack, lang }: { pack: StudyPack; lang: Lang }) {
  const answers = useStudy((state) => state.answers);
  const answer = useStudy((state) => state.answer);
  const [index, setIndex] = useState(0);
  const [done, setDone] = useState(false);
  const [picks, setPicks] = useState<Record<string, number>>({});
  const questions = pack.quiz;

  if (questions.length === 0) {
    return <p className="text-sm leading-relaxed text-mist">{t(lang, "noQuiz")}</p>;
  }

  const correctCount = questions.filter((question) => answers[`${pack.id}:${question.id}`] === "correct").length;
  if (done) {
    return (
      <div>
        <h3 className="font-serif text-2xl">{t(lang, "quizDone")}</h3>
        <p className="mt-2 text-sm text-mist">{t(lang, "yourScore")}</p>
        <p className="mt-1 text-3xl font-medium tabular-nums">
          {correctCount}
          <span className="text-mist"> / {questions.length}</span>
        </p>
        <p className="mt-3 max-w-xl text-sm leading-relaxed text-mist">{t(lang, "quizRule")}</p>
      </div>
    );
  }

  const question = questions[Math.min(index, questions.length - 1)];
  const key = `${pack.id}:${question.id}`;
  const mark = answers[key];
  const last = index >= questions.length - 1;

  return (
    <div>
      <p className="text-xs text-mist">{questionProgress(lang, index + 1, questions.length)}</p>
      <h3 className="mt-2 text-lg font-medium text-balance">{question.prompt}</h3>
      <ul className="mt-4 flex flex-col gap-2">
        {question.choices.map((choice, choiceIndex) => (
          <Choice
            key={`${question.id}-${choiceIndex}`}
            choice={choice}
            index={choiceIndex}
            question={question}
            mark={mark}
            picked={picks[key]}
            lang={lang}
            onPick={() => {
              if (mark) return;
              setPicks((current) => ({ ...current, [key]: choiceIndex }));
              answer(key, choiceIndex === question.answerIndex);
            }}
          />
        ))}
      </ul>
      {mark ? <p className="mt-4 text-sm leading-relaxed text-mist">{question.explanation}</p> : null}
      <div className="mt-4 flex flex-col gap-3">
        <p className="text-xs leading-relaxed text-faint">{t(lang, "quizRule")}</p>
        {mark ? (
          <button
            type="button"
            onClick={() => {
              if (last) setDone(true);
              else setIndex((value) => value + 1);
            }}
            className="h-11 rounded-lg bg-accent px-4 text-sm font-medium text-accent-ink"
          >
            {last ? t(lang, "results") : t(lang, "next")}
          </button>
        ) : null}
      </div>
    </div>
  );
}

function Choice({
  choice,
  index,
  question,
  mark,
  picked,
  lang,
  onPick,
}: {
  choice: string;
  index: number;
  question: QuizQuestion;
  mark: "correct" | "wrong" | undefined;
  picked: number | undefined;
  lang: Lang;
  onPick: () => void;
}) {
  const isAnswer = index === question.answerIndex;
  const isPicked = picked === index;
  let tag = "";
  let tone = "text-mist";
  if (mark && isAnswer) {
    tag = mark === "correct" ? t(lang, "correct") : t(lang, "theAnswer");
    tone = "text-good";
  } else if (mark === "wrong" && isPicked) {
    tag = t(lang, "notQuite");
    tone = "text-bad";
  }
  const border = mark && isAnswer ? "border-good" : mark === "wrong" && isPicked ? "border-bad" : "border-line";
  return (
    <li>
      <button
        type="button"
        disabled={Boolean(mark)}
        onClick={onPick}
        className={`flex min-h-11 w-full items-center justify-between gap-3 rounded-lg border bg-panel-2 px-3 py-2 text-left text-sm ${border}`}
      >
        <span className="text-pretty">{choice}</span>
        {tag ? <span className={`shrink-0 text-xs font-medium ${tone}`}>{tag}</span> : null}
      </button>
    </li>
  );
}

function SongPanel({ pack, uiLang }: { pack: StudyPack; uiLang: Lang }) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [heard, setHeard] = useState(false);
  const cacheKey = `${pack.language}:${hashText(pack.song.lyrics)}`;

  useEffect(() => {
    const audio = new Audio();
    audioRef.current = audio;
    const onEnd = () => setPlaying(false);
    audio.addEventListener("ended", onEnd);
    return () => {
      audio.pause();
      audio.removeEventListener("ended", onEnd);
    };
  }, [cacheKey]);

  async function toggle() {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
      return;
    }
    setError(null);
    let src = readAudio(cacheKey);
    if (!src) {
      setLoading(true);
      try {
        const result = await singStudySong({ data: { lyrics: pack.song.lyrics, language: pack.language } });
        if (!result.ok) {
          setError(errorText(uiLang, result.error === "ai_unavailable" ? "ai_unavailable" : "voice"));
          return;
        }
        src = result.audioBase64;
        writeAudio(cacheKey, src);
      } catch {
        setError(t(uiLang, "voiceError"));
        return;
      } finally {
        setLoading(false);
      }
    }
    audio.src = `data:audio/mpeg;base64,${src}`;
    try {
      await audio.play();
      setPlaying(true);
      setHeard(true);
    } catch {
      setError(t(uiLang, "voiceError"));
    }
  }

  return (
    <div>
      <h3 className="font-serif text-2xl text-balance">{pack.song.title}</h3>
      <p className="mt-2 max-w-xl text-sm leading-relaxed text-mist">{t(uiLang, "songHint")}</p>
      <pre className={`mt-4 text-sm leading-relaxed whitespace-pre-wrap ${pack.language === "hi" ? "font-sans" : "font-serif text-lg"}`}>
        {pack.song.lyrics}
      </pre>
      <button
        type="button"
        onClick={() => void toggle()}
        disabled={loading}
        className="mt-4 flex h-11 items-center gap-2 rounded-lg bg-accent px-4 text-sm font-medium text-accent-ink disabled:opacity-50"
      >
        {loading ? (
          <LoaderCircle className="size-4 animate-spin" aria-hidden="true" />
        ) : playing ? (
          <Pause className="size-4" aria-hidden="true" />
        ) : (
          <Play className="size-4" aria-hidden="true" />
        )}
        {loading ? t(uiLang, "making") : playing ? t(uiLang, "pause") : heard ? t(uiLang, "replay") : t(uiLang, "play")}
      </button>
      {error ? (
        <p role="alert" className="mt-2 text-sm text-bad">
          {error}
        </p>
      ) : null}
    </div>
  );
}
