export type Lang = "en" | "hi" | "hinglish";

export type NoteSection = {
  sourceId: string;
  heading: string;
  summary: string;
  bullets: string[];
  keyTerms: { term: string; meaning: string }[];
};

export type MindNode = {
  id: string;
  label: string;
  children: MindNode[];
};

export type QuizQuestion = {
  id: string;
  sourceId: string;
  prompt: string;
  choices: string[];
  answerIndex: number;
  explanation: string;
};

export type Song = {
  title: string;
  lyrics: string;
};

export type SourceInfo = {
  id: string;
  kind: "youtube" | "image" | "pdf";
  label: string;
  warning?: string;
  url?: string;
};

export type StudyPack = {
  id: string;
  title: string;
  language: Lang;
  createdAt: number;
  sources: SourceInfo[];
  notes: NoteSection[];
  mindmap: MindNode;
  quiz: QuizQuestion[];
  song: Song;
};

export type GeneratedPack = Omit<StudyPack, "id" | "createdAt">;

export type DraftSource =
  | { id: string; kind: "youtube"; url: string; transcript: string }
  | { id: string; kind: "image"; name: string; mime: string; base64: string; preview: string }
  | { id: string; kind: "pdf"; name: string; base64: string };

export type GenerateSource =
  | { id: string; kind: "youtube"; url: string; transcript?: string }
  | { id: string; kind: "image"; name: string; mime: string; base64: string }
  | { id: string; kind: "pdf"; name: string; base64: string };

export type GenerateInput = {
  language: Lang;
  sources: GenerateSource[];
};

export type GenerateResult =
  | { ok: true; pack: GeneratedPack }
  | { ok: false; error: string };

export type SingResult =
  | { ok: true; audioBase64: string }
  | { ok: false; error: string };

export const SAMPLE_ID = "sample";
export const XP_CORRECT = 10;
export const XP_WRONG = 5;
