import type { Lang } from "./types";

const copy = {
  en: {
    tagline: "Notes, maps, quizzes, and songs from your lessons.",
    newStudy: "New study",
    library: "Library",
    sample: "Sample",
    emptyLibrary: "Packs you make will show up here.",
    composerTitle: "New study pack",
    composerBody:
      "Add every YouTube lesson, image, and PDF. NoteMap writes notes for each one, then a mind map, a quiz, and a memory song.",
    ytPlaceholder: "Paste a YouTube link",
    add: "Add",
    addTranscript: "Paste transcript",
    hideTranscript: "Hide transcript",
    transcriptPlaceholder: "Optional. Paste the video transcript if you have it.",
    drop: "Drop images or PDFs here",
    browse: "Browse files",
    covers: "Notes will cover every source you added.",
    make: "Make my notes",
    making: "Writing your study pack",
    makingHint: "Reading every source, then notes, a mind map, a quiz, and a song.",
    notes: "Notes",
    map: "Mind map",
    quiz: "Quiz",
    song: "Song",
    play: "Play in a sweet voice",
    pause: "Pause",
    replay: "Play again",
    songHint: "A short memory song, read in Luna’s soft voice. Nothing plays until you press the button.",
    keyTerms: "Key terms",
    quizRule: "+10 XP for a correct answer. −5 XP for a wrong one. Your score never goes below zero. Only the first try counts.",
    next: "Next question",
    results: "See score",
    quizDone: "Quiz complete",
    correct: "Correct",
    notQuite: "Not quite",
    theAnswer: "Answer",
    explanation: "Why",
    remove: "Remove",
    confirmRemove: "Remove pack?",
    sources: "sources",
    source: "source",
    video: "Video",
    image: "Image",
    pdf: "PDF",
    notYoutube: "That doesn’t look like a YouTube link.",
    tooMany: "Five sources at a time. Make this pack, then start another.",
    tooBig: "That file is too big. Try a smaller image or a shorter PDF.",
    badFile: "Use a JPG, PNG, WEBP, or PDF.",
    needSource: "Add a video, image, or PDF first.",
    voiceError: "The voice didn’t come through. Try play again.",
    genError: "The study pack didn’t finish. Try again.",
    aiDown: "AI notes aren’t available right now.",
    aiBusy: "The AI is busy. Wait a moment and try again.",
    pdfBad: "That PDF couldn’t be read. Try another file, or photograph the pages and add them as images.",
    updateWithTranscript: "Remake with this transcript",
    updating: "Remaking notes",
    pasteHint: "Paste the YouTube transcript for precise notes.",
    lostFiles:
      "The original files aren’t on this device anymore. Start a new study pack and add every source again so none of them are skipped.",
    noQuiz: "No quiz for this pack yet. Add a transcript or a clearer photo and make it again.",
    mapHint: "Tap a branch to fold it. Scroll sideways if the map runs wide.",
    madeIn: "Written in",
    langEn: "English",
    langHi: "हिंदी",
    langHiName: "Hindi",
    langMix: "Hinglish",
    xp: "XP",
    yourScore: "This round",
    back: "Back to notes",
    whoTitle: "Remember me",
    whoBody: "Your name, packs, and XP stay on this device.",
    whoPlaceholder: "Your name",
    whoSave: "Remember me",
    hiName: "Hi",
    notYou: "Not you?",
  },
  hi: {
    tagline: "पाठ से नोट्स, माइंड मैप, क्विज़ और याद रखने वाला गाना।",
    newStudy: "नया अध्ययन",
    library: "संग्रह",
    sample: "नमूना",
    emptyLibrary: "आपके बनाए पैक यहाँ दिखेंगे।",
    composerTitle: "नया अध्ययन पैक",
    composerBody:
      "हर YouTube पाठ, चित्र और PDF जोड़ें। NoteMap हर स्रोत के नोट्स लिखेगा, फिर माइंड मैप, क्विज़ और एक यादगार गाना।",
    ytPlaceholder: "YouTube लिंक चिपकाएँ",
    add: "जोड़ें",
    addTranscript: "ट्रांसक्रिप्ट चिपकाएँ",
    hideTranscript: "ट्रांसक्रिप्ट छिपाएँ",
    transcriptPlaceholder: "वैकल्पिक। अगर ट्रांसक्रिप्ट है तो चिपकाएँ।",
    drop: "चित्र या PDF यहाँ छोड़ें",
    browse: "फ़ाइल चुनें",
    covers: "जोड़े गए हर स्रोत के नोट्स बनेंगे।",
    make: "मेरे नोट्स बनाओ",
    making: "अध्ययन पैक लिखा जा रहा है",
    makingHint: "हर स्रोत पढ़ा जा रहा है, फिर नोट्स, माइंड मैप, क्विज़ और गाना।",
    notes: "नोट्स",
    map: "माइंड मैप",
    quiz: "क्विज़",
    song: "गाना",
    play: "मीठी आवाज़ में सुनें",
    pause: "रोकें",
    replay: "फिर सुनें",
    songHint: "एक छोटा यादगार गाना, Luna की नरम आवाज़ में। बटन दबाने पर ही आवाज़ चलेगी।",
    keyTerms: "मुख्य शब्द",
    quizRule: "सही उत्तर पर +10 XP। गलत पर −5 XP। अंक शून्य से नीचे नहीं जाएँगे। केवल पहली कोशिश गिनेगी।",
    next: "अगला प्रश्न",
    results: "अंक देखें",
    quizDone: "क्विज़ पूरी हुई",
    correct: "सही",
    notQuite: "पूरा सही नहीं",
    theAnswer: "उत्तर",
    explanation: "कारण",
    remove: "हटाएँ",
    confirmRemove: "पैक हटाएँ?",
    sources: "स्रोत",
    source: "स्रोत",
    video: "वीडियो",
    image: "चित्र",
    pdf: "PDF",
    notYoutube: "यह YouTube लिंक नहीं लग रहा।",
    tooMany: "एक बार में पाँच स्रोत। यह पैक बनाएँ, फिर अगला शुरू करें।",
    tooBig: "फ़ाइल बहुत बड़ी है। छोटा चित्र या छोटा PDF आज़माएँ।",
    badFile: "JPG, PNG, WEBP या PDF इस्तेमाल करें।",
    needSource: "पहले वीडियो, चित्र या PDF जोड़ें।",
    voiceError: "आवाज़ नहीं आ सकी। फिर से चलाएँ।",
    genError: "अध्ययन पैक पूरा नहीं हुआ। फिर कोशिश करें।",
    aiDown: "अभी AI नोट्स उपलब्ध नहीं हैं।",
    aiBusy: "AI व्यस्त है। थोड़ी देर बाद कोशिश करें।",
    pdfBad: "यह PDF पढ़ा नहीं जा सका। दूसरी फ़ाइल आज़माएँ, या पन्नों की फ़ोटो चित्र के रूप में जोड़ें।",
    updateWithTranscript: "इस ट्रांसक्रिप्ट से फिर बनाएँ",
    updating: "नोट्स फिर बन रहे हैं",
    pasteHint: "सटीक नोट्स के लिए YouTube ट्रांसक्रिप्ट चिपकाएँ।",
    lostFiles:
      "मूल फ़ाइलें इस डिवाइस पर नहीं हैं। नया अध्ययन पैक शुरू करें और हर स्रोत फिर जोड़ें, ताकि कोई छूट न जाए।",
    noQuiz: "इस पैक में अभी क्विज़ नहीं है। ट्रांसक्रिप्ट या साफ़ फ़ोटो जोड़कर फिर बनाएँ।",
    mapHint: "शाखा समेटने के लिए टैप करें। नक्शा चौड़ा हो तो बगल में स्क्रॉल करें।",
    madeIn: "भाषा",
    langEn: "English",
    langHi: "हिंदी",
    langHiName: "हिंदी",
    langMix: "Hinglish",
    xp: "XP",
    yourScore: "यह राउंड",
    back: "नोट्स पर जाएँ",
    whoTitle: "मुझे याद रखो",
    whoBody: "आपका नाम, पैक और XP इसी डिवाइस पर रहेंगे।",
    whoPlaceholder: "आपका नाम",
    whoSave: "याद रखो",
    hiName: "नमस्ते",
    notYou: "आप नहीं?",
  },
  hinglish: {
    tagline: "Lesson se notes, mind map, quiz, aur yaad rakhne wala gaana.",
    newStudy: "Naya study",
    library: "Library",
    sample: "Sample",
    emptyLibrary: "Jo packs aap banaoge, woh yahin dikhenge.",
    composerTitle: "Naya study pack",
    composerBody:
      "Har YouTube lesson, image, aur PDF add karo. NoteMap har source ke notes likhega, phir mind map, quiz, aur ek memory song.",
    ytPlaceholder: "YouTube link paste karo",
    add: "Add",
    addTranscript: "Transcript paste karo",
    hideTranscript: "Transcript chhupao",
    transcriptPlaceholder: "Optional. Agar transcript hai to paste kar do.",
    drop: "Images ya PDFs yahan drop karo",
    browse: "Files choose karo",
    covers: "Jo source add kiye hain, un sabke notes banenge.",
    make: "Mere notes banao",
    making: "Study pack likha ja raha hai",
    makingHint: "Har source padh rahe hain, phir notes, mind map, quiz, aur song.",
    notes: "Notes",
    map: "Mind map",
    quiz: "Quiz",
    song: "Song",
    play: "Sweet voice mein suno",
    pause: "Pause",
    replay: "Phir suno",
    songHint: "Chhota memory song, Luna ki soft voice mein. Button dabane par hi audio chalega.",
    keyTerms: "Key terms",
    quizRule: "Sahi jawab par +10 XP. Galat par −5 XP. Score zero se neeche nahi jayega. Sirf pehli try count hoti hai.",
    next: "Agla sawal",
    results: "Score dekho",
    quizDone: "Quiz khatam",
    correct: "Sahi",
    notQuite: "Poora sahi nahi",
    theAnswer: "Jawab",
    explanation: "Kyun",
    remove: "Hatao",
    confirmRemove: "Pack hataun?",
    sources: "sources",
    source: "source",
    video: "Video",
    image: "Image",
    pdf: "PDF",
    notYoutube: "Yeh YouTube link nahi lag raha.",
    tooMany: "Ek baar mein paanch sources. Yeh pack banao, phir agla shuru karo.",
    tooBig: "File bahut badi hai. Chhoti image ya chhota PDF try karo.",
    badFile: "JPG, PNG, WEBP, ya PDF use karo.",
    needSource: "Pehle video, image, ya PDF add karo.",
    voiceError: "Awaaz nahi aayi. Play phir se dabao.",
    genError: "Study pack poora nahi hua. Phir try karo.",
    aiDown: "Abhi AI notes available nahi hain.",
    aiBusy: "AI busy hai. Thodi der baad try karo.",
    pdfBad: "Yeh PDF padha nahi ja saka. Dusri file try karo, ya pages ki photo image ki tarah add karo.",
    updateWithTranscript: "Is transcript se dubara banao",
    updating: "Notes dubara ban rahe hain",
    pasteHint: "Exact notes ke liye YouTube transcript paste karo.",
    lostFiles:
      "Original files is device par nahi hain. Naya study pack shuru karo aur har source dubara add karo, taaki koi skip na ho.",
    noQuiz: "Is pack mein abhi quiz nahi hai. Transcript ya clear photo add karke dubara banao.",
    mapHint: "Branch fold karne ke liye tap karo. Map wide ho to side mein scroll karo.",
    madeIn: "Language",
    langEn: "English",
    langHi: "हिंदी",
    langHiName: "Hindi",
    langMix: "Hinglish",
    xp: "XP",
    yourScore: "Yeh round",
    back: "Notes par jao",
    whoTitle: "Mujhe yaad rakho",
    whoBody: "Aapka naam, packs, aur XP isi device par rahenge.",
    whoPlaceholder: "Aapka naam",
    whoSave: "Yaad rakho",
    hiName: "Hi",
    notYou: "Aap nahi?",
  },
} as const;

export type CopyKey = keyof typeof copy.en;

export function t(lang: Lang, key: CopyKey): string {
  return copy[lang][key];
}

export function langLabel(lang: Lang, which: Lang): string {
  if (which === "en") return t(lang, "langEn");
  if (which === "hi") return t(lang, "langHi");
  return t(lang, "langMix");
}

export function packLangName(lang: Lang, packLang: Lang): string {
  if (packLang === "en") return "English";
  if (packLang === "hi") return lang === "en" ? "Hindi" : "हिंदी";
  return "Hinglish";
}

export function questionProgress(lang: Lang, index: number, total: number): string {
  if (lang === "hi") return `प्रश्न ${index} / ${total}`;
  if (lang === "hinglish") return `Sawal ${index} / ${total}`;
  return `Question ${index} of ${total}`;
}

export function sourceCountLabel(lang: Lang, count: number): string {
  const word = count === 1 ? t(lang, "source") : t(lang, "sources");
  return `${count} ${word}`;
}

export function kindLabel(lang: Lang, kind: "youtube" | "image" | "pdf"): string {
  if (kind === "youtube") return t(lang, "video");
  if (kind === "image") return t(lang, "image");
  return t(lang, "pdf");
}

export function errorText(lang: Lang, code: string): string {
  if (code === "ai_unavailable") return t(lang, "aiDown");
  if (code === "ai_busy") return t(lang, "aiBusy");
  if (code === "pdf_too_big" || code === "image_too_big") return t(lang, "tooBig");
  if (code === "pdf_unreadable") return t(lang, "pdfBad");
  if (code === "bad_url") return t(lang, "notYoutube");
  if (code === "need_source") return t(lang, "needSource");
  if (code === "voice") return t(lang, "voiceError");
  return t(lang, "genError");
}
