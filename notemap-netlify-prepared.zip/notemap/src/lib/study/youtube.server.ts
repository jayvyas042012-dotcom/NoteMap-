const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
const YT_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";

export type YoutubeMaterial = {
  videoId: string;
  title: string;
  author: string;
  transcript: string | null;
};

export function videoIdFromUrl(input: string): string | null {
  const value = input.trim();
  if (/^[A-Za-z0-9_-]{11}$/.test(value)) return value;
  try {
    const url = new URL(value);
    const host = url.hostname.replace(/^www\./, "");
    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0] ?? "";
      return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
    }
    if (
      host === "youtube.com" ||
      host === "m.youtube.com" ||
      host === "music.youtube.com" ||
      host === "youtube-nocookie.com"
    ) {
      if (url.pathname === "/watch") {
        const id = url.searchParams.get("v") ?? "";
        return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
      }
      const parts = url.pathname.split("/").filter(Boolean);
      if (["shorts", "embed", "live", "v"].includes(parts[0] ?? "") && parts[1]) {
        return /^[A-Za-z0-9_-]{11}$/.test(parts[1]) ? parts[1] : null;
      }
    }
  } catch {
    return null;
  }
  return null;
}

async function getText(url: string, init?: RequestInit, ms = 8000): Promise<string | null> {
  try {
    const res = await fetch(url, {
      ...init,
      signal: AbortSignal.timeout(ms),
      headers: {
        "User-Agent": UA,
        Accept: "*/*",
        ...(init?.headers ?? {}),
      },
    });
    if (!res.ok) return null;
    const text = await res.text();
    return text.trim() ? text : null;
  } catch {
    return null;
  }
}

function decodeEntities(value: string): string {
  return value
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_, n: string) => String.fromCodePoint(Number.parseInt(n, 16)))
    .replace(/&nbsp;/g, " ")
    .replace(/"/g, '"')
    .replace(/&#39;|'/g, "'")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/&/g, "&");
}

function cleanTranscript(text: string): string | null {
  const cleaned = text
    .replace(/\[(?:music|applause|laughter|inaudible)\]/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned.length > 80 ? cleaned.slice(0, 8000) : null;
}

function transcriptFromPayload(body: string): string | null {
  const trimmed = body.trim();
  if (!trimmed || trimmed.length < 20) return null;
  if (trimmed.startsWith("{") || trimmed.startsWith("[")) {
    try {
      const json = JSON.parse(trimmed) as {
        events?: { segs?: { utf8?: string }[] }[];
      };
      const events = Array.isArray(json) ? json : (json.events ?? []);
      const parts: string[] = [];
      for (const event of events) {
        const segs = (event as { segs?: { utf8?: string }[] }).segs ?? [];
        const line = segs.map((seg) => seg.utf8 ?? "").join("");
        const clean = line.replace(/\n/g, " ").replace(/\s+/g, " ").trim();
        if (clean) parts.push(clean);
      }
      return cleanTranscript(parts.join(" "));
    } catch {
      return null;
    }
  }
  const parts: string[] = [];
  const re = /<text\b[^>]*>([\s\S]*?)<\/text>/gi;
  let match: RegExpExecArray | null;
  while ((match = re.exec(trimmed))) {
    const line = decodeEntities(match[1].replace(/<[^>]+>/g, " ")).replace(/\s+/g, " ").trim();
    if (line) parts.push(line);
  }
  if (parts.length) return cleanTranscript(parts.join(" "));
  const lines = trimmed
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line && !line.includes("-->") && !line.startsWith("WEBVTT") && !/^\d+$/.test(line));
  return cleanTranscript(lines.join(" "));
}

async function captionsFromPlayer(clientName: "ANDROID" | "IOS", videoId: string, prefer: string): Promise<string | null> {
  const android = clientName === "ANDROID";
  const body = {
    context: {
      client: android
        ? {
            clientName: "ANDROID",
            clientVersion: "20.10.38",
            androidSdkVersion: 34,
            hl: "en",
            gl: "US",
          }
        : {
            clientName: "IOS",
            clientVersion: "20.10.4",
            deviceModel: "iPhone16,2",
            hl: "en",
            gl: "US",
          },
    },
    videoId,
    contentCheckOk: true,
    racyCheckOk: true,
  };
  const raw = await getText(`https://www.youtube.com/youtubei/v1/player?key=${YT_KEY}&prettyPrint=false`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "User-Agent": android
        ? "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip"
        : "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
      "X-YouTube-Client-Name": android ? "3" : "5",
      "X-YouTube-Client-Version": android ? "20.10.38" : "20.10.4",
    },
    body: JSON.stringify(body),
  });
  if (!raw) return null;
  try {
    const json = JSON.parse(raw) as {
      captions?: { playerCaptionsTracklistRenderer?: { captionTracks?: { baseUrl?: string; languageCode?: string }[] } };
    };
    const tracks = json.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
    const track =
      tracks.find((item) => item.languageCode === prefer && item.baseUrl) ??
      tracks.find((item) => item.languageCode === "en" && item.baseUrl) ??
      tracks.find((item) => item.baseUrl);
    if (!track?.baseUrl) return null;
    const url = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
    const caption = await getText(url);
    return caption ? transcriptFromPayload(caption) : null;
  } catch {
    return null;
  }
}

async function captionsFromTimedText(videoId: string, prefer: string): Promise<string | null> {
  const direct = await getText(
    `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(prefer)}&fmt=json3`,
  );
  const parsed = direct ? transcriptFromPayload(direct) : null;
  if (parsed) return parsed;
  if (prefer !== "en") {
    const english = await getText(`https://www.youtube.com/api/timedtext?v=${videoId}&lang=en&fmt=json3`);
    const englishText = english ? transcriptFromPayload(english) : null;
    if (englishText) return englishText;
  }
  const list = await getText(`https://www.youtube.com/api/timedtext?type=list&v=${videoId}`);
  if (!list) return null;
  const lang = /lang_code="([^"]+)"/i.exec(list)?.[1];
  if (!lang) return null;
  const body = await getText(
    `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(lang)}&fmt=json3`,
  );
  return body ? transcriptFromPayload(body) : null;
}

async function captionsFromPackage(videoId: string, prefer: string): Promise<string | null> {
  try {
    const { YoutubeTranscript } = await import("@danielxceron/youtube-transcript");
    const rows = await YoutubeTranscript.fetchTranscript(videoId, { lang: prefer, timeoutMs: 12000 });
    return cleanTranscript(rows.map((row) => row.text).join(" "));
  } catch {
    if (prefer === "en") return null;
    try {
      const { YoutubeTranscript } = await import("@danielxceron/youtube-transcript");
      const rows = await YoutubeTranscript.fetchTranscript(videoId, { lang: "en", timeoutMs: 12000 });
      return cleanTranscript(rows.map((row) => row.text).join(" "));
    } catch {
      return null;
    }
  }
}

async function captionsFromInvidious(videoId: string, prefer: string): Promise<string | null> {
  const listRaw = await getText(`https://inv.nadeko.net/api/v1/captions/${videoId}`);
  if (!listRaw) return null;
  try {
    const list = JSON.parse(listRaw) as { captions?: { label?: string; languageCode?: string; url?: string }[] };
    const tracks = list.captions ?? [];
    const track = tracks.find((item) => item.languageCode === prefer) ?? tracks.find((item) => item.languageCode === "en") ?? tracks[0];
    if (!track?.url) return null;
    const body = await getText(`https://inv.nadeko.net${track.url}`);
    return body ? transcriptFromPayload(body) : null;
  } catch {
    return null;
  }
}

function firstUseful(tasks: Promise<string | null>[]): Promise<string | null> {
  return new Promise((resolve) => {
    let pending = tasks.length;
    let settled = false;
    const finish = (value: string | null) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    if (pending === 0) {
      finish(null);
      return;
    }
    for (const task of tasks) {
      task
        .then((text) => {
          if (text) finish(text);
        })
        .catch(() => undefined)
        .finally(() => {
          pending -= 1;
          if (pending === 0) finish(null);
        });
    }
  });
}

export async function loadYouTube(url: string, pasted?: string, prefer = "en"): Promise<YoutubeMaterial> {
  const videoId = videoIdFromUrl(url);
  if (!videoId) throw new Error("bad_url");
  const pastedClean = pasted?.trim() ? cleanTranscript(pasted) ?? pasted.trim().slice(0, 8000) : null;
  const [metaRaw, transcript] = await Promise.all([
    getText(`https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}`),
    pastedClean && pastedClean.length > 40
      ? Promise.resolve(pastedClean)
      : firstUseful([
          captionsFromPackage(videoId, prefer),
          captionsFromPlayer("ANDROID", videoId, prefer),
          captionsFromPlayer("IOS", videoId, prefer),
          captionsFromTimedText(videoId, prefer),
          captionsFromInvidious(videoId, prefer),
        ]),
  ]);
  let title = `YouTube ${videoId}`;
  let author = "";
  if (metaRaw) {
    try {
      const meta = JSON.parse(metaRaw) as { title?: string; author_name?: string };
      if (meta.title) title = meta.title;
      if (meta.author_name) author = meta.author_name;
    } catch {
      /* title stays as the id */
    }
  }
  return { videoId, title, author, transcript };
}
