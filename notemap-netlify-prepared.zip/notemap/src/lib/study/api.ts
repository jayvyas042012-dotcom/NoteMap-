import { createServerFn } from "@tanstack/react-start";
import type { GenerateInput, Lang } from "./types";

export const generateStudyPack = createServerFn({ method: "POST" })
  .validator((data: GenerateInput) => {
    if (!data || !Array.isArray(data.sources) || data.sources.length === 0) {
      throw new Error("need_source");
    }
    if (data.sources.length > 5) throw new Error("too_many");
    if (data.language !== "en" && data.language !== "hi" && data.language !== "hinglish") {
      throw new Error("bad_lang");
    }
    return data;
  })
  .handler(async ({ data }) => {
    const { runGenerate } = await import("./engine.server");
    return runGenerate(data);
  });

export const singStudySong = createServerFn({ method: "POST" })
  .validator((data: { lyrics: string; language: Lang }) => {
    const lyrics = (data?.lyrics ?? "").trim();
    if (!lyrics) throw new Error("voice");
    const language = data.language;
    if (language !== "en" && language !== "hi" && language !== "hinglish") throw new Error("bad_lang");
    return { lyrics: lyrics.slice(0, 1800), language };
  })
  .handler(async ({ data }) => {
    const { runSing } = await import("./engine.server");
    return runSing(data.lyrics, data.language);
  });
