import type { Lang, StudyPack } from "./types";
import { SAMPLE_ID } from "./types";

const en: StudyPack = {
  id: SAMPLE_ID,
  title: "Photosynthesis",
  language: "en",
  createdAt: 0,
  sources: [
    { id: "sample-src", kind: "pdf", label: "PDF · Class notes" },
  ],
  notes: [
    {
      sourceId: "sample-src",
      heading: "How plants make food",
      summary:
        "Photosynthesis is how green plants make their own food. Leaves take in light, water, and carbon dioxide. Chlorophyll catches the light. The plant makes glucose and releases oxygen.",
      bullets: [
        "Most of the work happens in the leaves.",
        "Chlorophyll is the green pigment that absorbs light.",
        "Water usually comes up from the roots.",
        "Carbon dioxide enters through tiny pores called stomata.",
        "Glucose is the sugar the plant uses for energy and growth.",
        "Oxygen is released into the air.",
      ],
      keyTerms: [
        { term: "Photosynthesis", meaning: "Making food from light, water, and carbon dioxide." },
        { term: "Chlorophyll", meaning: "Green pigment that captures light energy." },
        { term: "Glucose", meaning: "The sugar produced as food." },
        { term: "Stomata", meaning: "Tiny pores that let gases in and out of the leaf." },
      ],
    },
  ],
  mindmap: {
    id: "root",
    label: "Photosynthesis",
    children: [
      {
        id: "in",
        label: "What goes in",
        children: [
          { id: "in-l", label: "Light", children: [] },
          { id: "in-w", label: "Water", children: [] },
          { id: "in-c", label: "Carbon dioxide", children: [] },
        ],
      },
      {
        id: "where",
        label: "Where it happens",
        children: [
          { id: "where-l", label: "Leaves", children: [] },
          { id: "where-c", label: "Chlorophyll", children: [] },
          { id: "where-s", label: "Stomata", children: [] },
        ],
      },
      {
        id: "out",
        label: "What comes out",
        children: [
          { id: "out-g", label: "Glucose", children: [] },
          { id: "out-o", label: "Oxygen", children: [] },
        ],
      },
    ],
  },
  quiz: [
    {
      id: "q1",
      sourceId: "sample-src",
      prompt: "What do plants make as food during photosynthesis?",
      choices: ["Glucose", "Salt", "Iron", "Sand"],
      answerIndex: 0,
      explanation: "The sugar made in photosynthesis is glucose.",
    },
    {
      id: "q2",
      sourceId: "sample-src",
      prompt: "Which gas do plants take from the air?",
      choices: ["Helium", "Carbon dioxide", "Neon", "Chlorine"],
      answerIndex: 1,
      explanation: "Carbon dioxide enters the leaf through stomata.",
    },
    {
      id: "q3",
      sourceId: "sample-src",
      prompt: "What does chlorophyll do?",
      choices: ["Pumps blood", "Captures light", "Stores salt", "Breaks rock"],
      answerIndex: 1,
      explanation: "Chlorophyll is the green pigment that absorbs light.",
    },
    {
      id: "q4",
      sourceId: "sample-src",
      prompt: "Which gas is released?",
      choices: ["Methane", "Neon", "Oxygen", "Chlorine"],
      answerIndex: 2,
      explanation: "Oxygen leaves the plant and goes into the air.",
    },
    {
      id: "q5",
      sourceId: "sample-src",
      prompt: "Where does most photosynthesis happen?",
      choices: ["Only in the roots", "In the leaves", "Only in the flower", "In the bark"],
      answerIndex: 1,
      explanation: "Leaves hold the chlorophyll and the stomata.",
    },
    {
      id: "q6",
      sourceId: "sample-src",
      prompt: "Which three things does photosynthesis need?",
      choices: [
        "Light, water, and carbon dioxide",
        "Salt, sand, and wind",
        "Oil, heat, and iron",
        "Milk, sugar, and yeast",
      ],
      answerIndex: 0,
      explanation: "Light, water, and carbon dioxide are the inputs.",
    },
  ],
  song: {
    title: "Light, water, air",
    lyrics: `Green leaves are kitchens, tiny and bright
They cook up sugar using the light
Water comes in, the air brings the rest
Carbon dioxide starts the quest

Chlorophyll catches the rays of the sun
Glucose is made when the cooking is done
Oxygen leaves so the rest of us breathe
Plants feed the world with the food they achieve

Light, water, air — remember these three
Sugar for growth, and oxygen free`,
  },
};

const hi: StudyPack = {
  id: SAMPLE_ID,
  title: "प्रकाश संश्लेषण",
  language: "hi",
  createdAt: 0,
  sources: [{ id: "sample-src", kind: "pdf", label: "PDF · कक्षा नोट्स" }],
  notes: [
    {
      sourceId: "sample-src",
      heading: "पौधे भोजन कैसे बनाते हैं",
      summary:
        "प्रकाश संश्लेषण वह प्रक्रिया है जिसमें हरे पौधे अपना भोजन बनाते हैं। पत्तियाँ प्रकाश, पानी और कार्बन डाइऑक्साइड लेती हैं। क्लोरोफिल प्रकाश को पकड़ता है। पौधा ग्लूकोज बनाता है और ऑक्सीजन छोड़ता है।",
      bullets: [
        "ज़्यादातर काम पत्तियों में होता है।",
        "क्लोरोफिल हरा रंग है जो प्रकाश सोखता है।",
        "पानी अक्सर जड़ों से ऊपर आता है।",
        "कार्बन डाइऑक्साइड स्टोमेटा नाम के छोटे छिद्रों से अंदर जाती है।",
        "ग्लूकोज वह शर्करा है जिससे पौधे को ऊर्जा मिलती है।",
        "ऑक्सीजन हवा में निकलती है।",
      ],
      keyTerms: [
        { term: "प्रकाश संश्लेषण", meaning: "प्रकाश, पानी और कार्बन डाइऑक्साइड से भोजन बनना।" },
        { term: "क्लोरोफिल", meaning: "हरा रंग जो प्रकाश की ऊर्जा पकड़ता है।" },
        { term: "ग्लूकोज", meaning: "भोजन के रूप में बनी शर्करा।" },
        { term: "स्टोमेटा", meaning: "पत्ती के छोटे छिद्र जिनसे गैसें आती-जाती हैं।" },
      ],
    },
  ],
  mindmap: {
    id: "root",
    label: "प्रकाश संश्लेषण",
    children: [
      {
        id: "in",
        label: "अंदर क्या जाता है",
        children: [
          { id: "in-l", label: "प्रकाश", children: [] },
          { id: "in-w", label: "पानी", children: [] },
          { id: "in-c", label: "कार्बन डाइऑक्साइड", children: [] },
        ],
      },
      {
        id: "where",
        label: "कहाँ होता है",
        children: [
          { id: "where-l", label: "पत्तियाँ", children: [] },
          { id: "where-c", label: "क्लोरोफिल", children: [] },
          { id: "where-s", label: "स्टोमेटा", children: [] },
        ],
      },
      {
        id: "out",
        label: "बाहर क्या आता है",
        children: [
          { id: "out-g", label: "ग्लूकोज", children: [] },
          { id: "out-o", label: "ऑक्सीजन", children: [] },
        ],
      },
    ],
  },
  quiz: [
    {
      id: "q1",
      sourceId: "sample-src",
      prompt: "प्रकाश संश्लेषण में पौधे भोजन के रूप में क्या बनाते हैं?",
      choices: ["ग्लूकोज", "नमक", "लोहा", "रेत"],
      answerIndex: 0,
      explanation: "इस प्रक्रिया में बनी शर्करा ग्लूकोज है।",
    },
    {
      id: "q2",
      sourceId: "sample-src",
      prompt: "पौधे हवा से कौन-सी गैस लेते हैं?",
      choices: ["हीलियम", "कार्बन डाइऑक्साइड", "नियॉन", "क्लोरीन"],
      answerIndex: 1,
      explanation: "कार्बन डाइऑक्साइड स्टोमेटा से पत्ती में जाती है।",
    },
    {
      id: "q3",
      sourceId: "sample-src",
      prompt: "क्लोरोफिल क्या करता है?",
      choices: ["खून पंप करता है", "प्रकाश पकड़ता है", "नमक रखता है", "पत्थर तोड़ता है"],
      answerIndex: 1,
      explanation: "क्लोरोफिल हरा रंग है जो प्रकाश सोखता है।",
    },
    {
      id: "q4",
      sourceId: "sample-src",
      prompt: "कौन-सी गैस बाहर निकलती है?",
      choices: ["मीथेन", "नियॉन", "ऑक्सीजन", "क्लोरीन"],
      answerIndex: 2,
      explanation: "ऑक्सीजन पौधे से हवा में जाती है।",
    },
    {
      id: "q5",
      sourceId: "sample-src",
      prompt: "प्रकाश संश्लेषण ज़्यादातर कहाँ होता है?",
      choices: ["केवल जड़ों में", "पत्तियों में", "केवल फूल में", "छाल में"],
      answerIndex: 1,
      explanation: "पत्तियों में क्लोरोफिल और स्टोमेटा होते हैं।",
    },
    {
      id: "q6",
      sourceId: "sample-src",
      prompt: "प्रकाश संश्लेषण के लिए तीन चीज़ें कौन-सी हैं?",
      choices: [
        "प्रकाश, पानी और कार्बन डाइऑक्साइड",
        "नमक, रेत और हवा",
        "तेल, गर्मी और लोहा",
        "दूध, चीनी और यीस्ट",
      ],
      answerIndex: 0,
      explanation: "प्रकाश, पानी और कार्बन डाइऑक्साइड अंदर जाते हैं।",
    },
  ],
  song: {
    title: "रोशनी, पानी, हवा",
    lyrics: `हरी पत्ती रसोई है, छोटी और साफ़
रोशनी से बनता है मीठा भोजन साफ़
पानी जड़ से आता है, हवा देती साथ
कार्बन डाइऑक्साइड से शुरू होता काम

क्लोरोफिल धूप पकड़ता, रंग उसका हरा
ग्लूकोज बन जाता है, भोजन बन पड़ा
ऑक्सीजन निकलती है, साँस हम लेते हैं
पौधे दुनिया पालते, याद इसे रखते हैं

रोशनी, पानी, हवा — तीनों याद रखो
चीनी से बढ़ो, ऑक्सीजन हवा को दो`,
  },
};

const hinglish: StudyPack = {
  id: SAMPLE_ID,
  title: "Photosynthesis",
  language: "hinglish",
  createdAt: 0,
  sources: [{ id: "sample-src", kind: "pdf", label: "PDF · Class notes" }],
  notes: [
    {
      sourceId: "sample-src",
      heading: "Plants apna khana kaise banate hain",
      summary:
        "Photosynthesis woh process hai jisme green plants apna food banate hain. Leaves light, water, aur carbon dioxide leti hain. Chlorophyll light pakadta hai. Plant glucose banata hai aur oxygen chhodta hai.",
      bullets: [
        "Zyadatar kaam leaves mein hota hai.",
        "Chlorophyll green pigment hai jo light absorb karta hai.",
        "Water aksar roots se upar aata hai.",
        "Carbon dioxide stomata naam ke chhote pores se andar jaati hai.",
        "Glucose woh sugar hai jo plant ko energy deti hai.",
        "Oxygen hawa mein nikal jaati hai.",
      ],
      keyTerms: [
        { term: "Photosynthesis", meaning: "Light, water, aur carbon dioxide se food banana." },
        { term: "Chlorophyll", meaning: "Green pigment jo light energy pakadta hai." },
        { term: "Glucose", meaning: "Food ke roop mein bani sugar." },
        { term: "Stomata", meaning: "Leaf ke chhote pores jinse gas aati-jaati hai." },
      ],
    },
  ],
  mindmap: {
    id: "root",
    label: "Photosynthesis",
    children: [
      {
        id: "in",
        label: "Andar kya jaata hai",
        children: [
          { id: "in-l", label: "Light", children: [] },
          { id: "in-w", label: "Water", children: [] },
          { id: "in-c", label: "Carbon dioxide", children: [] },
        ],
      },
      {
        id: "where",
        label: "Kahan hota hai",
        children: [
          { id: "where-l", label: "Leaves", children: [] },
          { id: "where-c", label: "Chlorophyll", children: [] },
          { id: "where-s", label: "Stomata", children: [] },
        ],
      },
      {
        id: "out",
        label: "Bahar kya aata hai",
        children: [
          { id: "out-g", label: "Glucose", children: [] },
          { id: "out-o", label: "Oxygen", children: [] },
        ],
      },
    ],
  },
  quiz: [
    {
      id: "q1",
      sourceId: "sample-src",
      prompt: "Photosynthesis mein plants food ke roop mein kya banate hain?",
      choices: ["Glucose", "Namak", "Loha", "Ret"],
      answerIndex: 0,
      explanation: "Jo sugar banti hai, uska naam glucose hai.",
    },
    {
      id: "q2",
      sourceId: "sample-src",
      prompt: "Plants hawa se kaunsi gas lete hain?",
      choices: ["Helium", "Carbon dioxide", "Neon", "Chlorine"],
      answerIndex: 1,
      explanation: "Carbon dioxide stomata se leaf mein jaati hai.",
    },
    {
      id: "q3",
      sourceId: "sample-src",
      prompt: "Chlorophyll kya karta hai?",
      choices: ["Khoon pump karta hai", "Light pakadta hai", "Namak rakhta hai", "Patthar todta hai"],
      answerIndex: 1,
      explanation: "Chlorophyll green pigment hai jo light absorb karta hai.",
    },
    {
      id: "q4",
      sourceId: "sample-src",
      prompt: "Kaunsi gas bahar nikalti hai?",
      choices: ["Methane", "Neon", "Oxygen", "Chlorine"],
      answerIndex: 2,
      explanation: "Oxygen plant se hawa mein chali jaati hai.",
    },
    {
      id: "q5",
      sourceId: "sample-src",
      prompt: "Photosynthesis zyadatar kahan hota hai?",
      choices: ["Sirf roots mein", "Leaves mein", "Sirf flower mein", "Bark mein"],
      answerIndex: 1,
      explanation: "Leaves mein chlorophyll aur stomata hote hain.",
    },
    {
      id: "q6",
      sourceId: "sample-src",
      prompt: "Photosynthesis ke teen inputs kaunse hain?",
      choices: [
        "Light, water, aur carbon dioxide",
        "Namak, ret, aur hawa",
        "Tel, garmi, aur loha",
        "Doodh, cheeni, aur yeast",
      ],
      answerIndex: 0,
      explanation: "Light, water, aur carbon dioxide andar jaate hain.",
    },
  ],
  song: {
    title: "Light, water, air",
    lyrics: `Hari patti kitchen hai, chhoti aur bright
Sugar banti hai yahin, using the light
Water root se aata hai, air laati saath
Carbon dioxide se shuru hota kaam

Chlorophyll dhoop pakde, rang uska green
Glucose ban jaata hai, food ready seen
Oxygen nikalta hai, saans hum lete hain
Plants duniya paalte, yaad ise rakhte hain

Light, water, air — teenon yaad rakho
Sugar se badho, oxygen hawa ko do`,
  },
};

const packs: Record<Lang, StudyPack> = { en, hi, hinglish };

export function samplePack(lang: Lang): StudyPack {
  return packs[lang];
}
