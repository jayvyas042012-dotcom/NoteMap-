import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { Lang, StudyPack } from "./types";
import { SAMPLE_ID, XP_CORRECT, XP_WRONG } from "./types";

type AnswerMark = "correct" | "wrong";

let dbPromise: Promise<IDBDatabase> | null = null;

function memoryDb(): Promise<IDBDatabase> {
  if (typeof indexedDB === "undefined") return Promise.reject(new Error("no-idb"));
  if (!dbPromise) {
    dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open("notemap-memory", 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains("kv")) database.createObjectStore("kv");
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        dbPromise = null;
        reject(request.error ?? new Error("idb"));
      };
    });
  }
  return dbPromise;
}

async function idbGet(key: string): Promise<string | null> {
  try {
    const database = await memoryDb();
    const value = await new Promise<string | undefined>((resolve, reject) => {
      const request = database.transaction("kv", "readonly").objectStore("kv").get(key);
      request.onsuccess = () => resolve(request.result as string | undefined);
      request.onerror = () => reject(request.error);
    });
    return value ?? null;
  } catch {
    return null;
  }
}

async function idbSet(key: string, value: string): Promise<void> {
  try {
    const database = await memoryDb();
    await new Promise<void>((resolve, reject) => {
      const request = database.transaction("kv", "readwrite").objectStore("kv").put(value, key);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch {
    /* local copy still counts */
  }
}

const memoryStorage = {
  getItem: async (key: string) => {
    let local: string | null = null;
    try {
      local = typeof localStorage === "undefined" ? null : localStorage.getItem(key);
    } catch {
      local = null;
    }
    if (local) return local;
    return Promise.race([idbGet(key), new Promise<null>((resolve) => setTimeout(() => resolve(null), 400))]);
  },
  setItem: (key: string, value: string) => {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* quota or private mode */
    }
    void idbSet(key, value);
  },
  removeItem: async (key: string) => {
    try {
      localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
    try {
      const database = await memoryDb();
      await new Promise<void>((resolve, reject) => {
        const request = database.transaction("kv", "readwrite").objectStore("kv").delete(key);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      });
    } catch {
      /* ignore */
    }
  },
};

type StudyState = {
  lang: Lang;
  name: string;
  packs: StudyPack[];
  activeId: string;
  xp: number;
  correct: number;
  wrong: number;
  answers: Record<string, AnswerMark>;
  lastDelta: number | null;
  lastDeltaAt: number;
  setLang: (lang: Lang) => void;
  setName: (name: string) => void;
  setActive: (id: string) => void;
  addPack: (pack: StudyPack) => void;
  replacePack: (pack: StudyPack) => void;
  removePack: (id: string) => void;
  answer: (key: string, isCorrect: boolean) => { applied: number; xp: number } | null;
  clearDelta: () => void;
};

export const useStudy = create<StudyState>()(
  persist(
    (set, get) => ({
      lang: "en",
      name: "",
      packs: [],
      activeId: SAMPLE_ID,
      xp: 0,
      correct: 0,
      wrong: 0,
      answers: {},
      lastDelta: null,
      lastDeltaAt: 0,
      setLang: (lang) => set({ lang }),
      setName: (name) => set({ name: name.trim().slice(0, 40) }),
      setActive: (id) => set({ activeId: id }),
      addPack: (pack) => set({ packs: [pack, ...get().packs.filter((item) => item.id !== pack.id)], activeId: pack.id }),
      replacePack: (pack) =>
        set({
          packs: get().packs.map((item) => (item.id === pack.id ? pack : item)),
          activeId: pack.id,
        }),
      removePack: (id) => {
        if (id === SAMPLE_ID) return;
        const packs = get().packs.filter((item) => item.id !== id);
        const activeId = get().activeId === id ? SAMPLE_ID : get().activeId;
        set({ packs, activeId });
      },
      answer: (key, isCorrect) => {
        const state = get();
        if (state.answers[key]) return null;
        const raw = isCorrect ? XP_CORRECT : -XP_WRONG;
        const xp = Math.max(0, state.xp + raw);
        const applied = xp - state.xp;
        set({
          xp,
          correct: state.correct + (isCorrect ? 1 : 0),
          wrong: state.wrong + (isCorrect ? 0 : 1),
          answers: { ...state.answers, [key]: isCorrect ? "correct" : "wrong" },
          lastDelta: applied === 0 ? raw : applied,
          lastDeltaAt: Date.now(),
        });
        return { applied, xp };
      },
      clearDelta: () => set({ lastDelta: null }),
    }),
    {
      name: "notemap-v1",
      skipHydration: true,
      storage: createJSONStorage(() => memoryStorage),
      partialize: (state) => ({
        lang: state.lang,
        name: state.name,
        packs: state.packs,
        activeId: state.activeId,
        xp: state.xp,
        correct: state.correct,
        wrong: state.wrong,
        answers: state.answers,
      }),
    },
  ),
);
