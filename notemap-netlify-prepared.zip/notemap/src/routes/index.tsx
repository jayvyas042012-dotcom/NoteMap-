import { createFileRoute } from "@tanstack/react-router";
import { NoteMapApp } from "@/components/notemap/app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <NoteMapApp />;
}
